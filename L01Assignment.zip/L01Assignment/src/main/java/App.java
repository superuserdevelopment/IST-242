/*
 * @author Arya Samarth
 * The Pennsylvania State University
 * aps6607@psu.edu
 */
import com.superuserdev.l01assignment.Model.Model;
public class App {
    public static void main(String args[]){
        Model model = new Model();
    }
}
